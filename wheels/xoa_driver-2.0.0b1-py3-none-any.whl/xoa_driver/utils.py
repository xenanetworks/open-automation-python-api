#: Helper functions

from xoa_driver.internals.core.transporter.funcs import (
    apply,
    apply_iter,
)


__all__ = (
    "apply",
    "apply_iter",
)
