from . import module_l47 as l47m


class ModuleL47VE(l47m.ModuleL47):
    """
    Representation of a L47 test module on a virtual tester.
    """
    ...
